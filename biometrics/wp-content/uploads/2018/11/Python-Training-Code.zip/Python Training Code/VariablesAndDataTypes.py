age=30
taxiFare = 4.6

fullname="Monica Geller"

print(fullname)

print(fullname[0:6])

print(fullname[4:])

print("Welcome " + fullname[0:6])

fullnames = ['Bereket', 'Monica', 'Jack', 'Solomon', 'Chandler']

print(fullnames[2:])

print(fullnames * 3)

friends = ('Belay', 'Donald')

print(friends)

numberDetails = {}
numberDetails[1]="one"
numberDetails[3]='three'

numberDetails['four']="aslkfh aslkfjalksdf ahsflkas dfksdhf asdflkhasdmf askldf a"


print(numberDetails['four'])



