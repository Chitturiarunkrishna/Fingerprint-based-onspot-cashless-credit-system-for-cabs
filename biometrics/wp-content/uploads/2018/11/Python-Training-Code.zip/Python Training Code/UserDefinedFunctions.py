def AddToNumbers(firstValue, thirdValue, secondValue=5):
    result = firstValue + secondValue + thirdValue

    return result


sum = AddToNumbers(firstValue=23, thirdValue=4)

print(sum)