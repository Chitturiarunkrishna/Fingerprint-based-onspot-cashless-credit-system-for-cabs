age = 10

print(age)
age = 10 + 4
print(age)

age = age + 1
age += 1

age = age - 1
age -= 1

result = age > 30
print(result)

myAge = 30
aberaAge = 20

result = not myAge > aberaAge and myAge > 45
print(result)

result = myAge > aberaAge or myAge > 45
print(result)
