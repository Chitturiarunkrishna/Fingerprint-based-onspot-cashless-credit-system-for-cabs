fullname = input("Enter Your Name: ")

print("Welcome " + fullname)

age = input("Enter your age: ")

if str(age) > 17:
    print("Qualified for Facebook")
else:
    print("Not Qualified for Facebook")


int("")

float("")

str(3.9)