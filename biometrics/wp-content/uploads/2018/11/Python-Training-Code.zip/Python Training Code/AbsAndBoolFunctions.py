value = 2323
result = abs(value)

print(result)

result = bool("2wr")

print(result)