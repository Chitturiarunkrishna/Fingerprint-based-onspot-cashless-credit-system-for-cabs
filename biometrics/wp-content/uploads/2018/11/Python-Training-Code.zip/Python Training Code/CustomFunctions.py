def Greeting():
    print("Hello World")

Greeting()

def Add(value1, value2):
    result = value1 + value2
    return result

sum = Add(3,5)

print(sum)