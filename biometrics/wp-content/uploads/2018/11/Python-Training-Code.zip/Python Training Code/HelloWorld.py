print("Hello World from Bereket")
