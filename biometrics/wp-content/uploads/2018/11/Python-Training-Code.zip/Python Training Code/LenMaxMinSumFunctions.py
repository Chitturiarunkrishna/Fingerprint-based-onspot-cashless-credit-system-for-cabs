value = [1,5,4,3,2,7]
result = len(value)

print(result)

stringValue = ['a','d','e','D','A']
result = max(stringValue)
print(result)

result = min(stringValue)
print(result)

result = sum(value)
print(result)