i = 0

while i < 10:
    print(i)
    i = i + 2


pattern = ""
for i in range(0, 5):
    x=0
    while x < 1:
        pattern = pattern + "*"
        x = x + 1

    print(pattern)