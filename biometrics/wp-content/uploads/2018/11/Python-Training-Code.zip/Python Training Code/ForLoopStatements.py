
for i in range(0, 10, 2):
    print(i)


studentNames = ['John', 'Jared', 'Abel', 'Donald']
print(studentNames)

for name in studentNames:
    print(name)