age = 20

if(age < 18):
    print("You are a child")
elif(age > 18):
    print("You are not a child")
elif(age == 18):
    print("Welcome")

mark = -11;

if(mark >= 90):
    print("Your grade is A")
elif(mark >= 80):
    print("Your grade is B")
elif(mark >= 50):
    print("Your grade is C")
else:
    print("Your grade is F")
