firstValue = 34
secondValue = 9

result = firstValue + secondValue

print(result)
result = firstValue * secondValue

print(result)
result = firstValue - secondValue

print(result)
result = firstValue / secondValue

print(result)

result = firstValue > secondValue
print(result)

result = firstValue < secondValue
print(result)

result = firstValue >= secondValue
print(result)

result = firstValue <= secondValue
print(result)

result = firstValue != secondValue
print(result)
