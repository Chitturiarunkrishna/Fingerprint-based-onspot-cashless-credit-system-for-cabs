parameter = "bereket"
result = dir(parameter)

print(result)

result = help(parameter.islower)

print(result)